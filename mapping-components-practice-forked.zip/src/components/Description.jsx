import React from "react";

function Desc(props) {
  return <dd>{props.desc}</dd>;
}

export default Desc;
