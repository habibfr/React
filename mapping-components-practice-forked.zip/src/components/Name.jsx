import React from "react";

function Name(props) {
  return <span>{props.name}</span>;
}

export default Name;
